import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { useAuth } from "./_core/hooks/useAuth";
import DashboardLayout from "./components/DashboardLayout";
import AdminDashboard from "./pages/admin/Dashboard";
import AdminUsers from "./pages/admin/Users";
import AdminAmbulances from "./pages/admin/Ambulances";
import AdminDrivers from "./pages/admin/Drivers";
import AdminHospitals from "./pages/admin/Hospitals";
import AdminEmergencies from "./pages/admin/Emergencies";
import AdminReports from "./pages/admin/Reports";
import AdminSettings from "./pages/admin/Settings";
import UserDashboard from "./pages/user/Dashboard";
import UserProfile from "./pages/user/Profile";
import UserTracking from "./pages/user/Tracking";
import UserEmergencyContacts from "./pages/user/EmergencyContacts";
import Home from "./pages/Home";
import { Spinner } from "./components/ui/spinner";

function AdminRoutes() {
  return (
    <DashboardLayout>
      <Switch>
        <Route path="/users" component={AdminUsers} />
        <Route path="/ambulances" component={AdminAmbulances} />
        <Route path="/drivers" component={AdminDrivers} />
        <Route path="/hospitals" component={AdminHospitals} />
        <Route path="/emergencies" component={AdminEmergencies} />
        <Route path="/reports" component={AdminReports} />
        <Route path="/settings" component={AdminSettings} />
        <Route component={NotFound} />
      </Switch>
    </DashboardLayout>
  );
}

function UserRoutes() {
  return (
    <DashboardLayout>
      <Switch>
        <Route path="/profile" component={UserProfile} />
        <Route path="/tracking/:emergencyId" component={UserTracking} />
        <Route path="/emergency-contacts" component={UserEmergencyContacts} />
        <Route component={NotFound} />
      </Switch>
    </DashboardLayout>
  );
}

function Router() {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Spinner />
      </div>
    );
  }

  // Unauthenticated users see the landing page
  if (!user) {
    return (
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/404" component={NotFound} />
        <Route component={Home} />
      </Switch>
    );
  }

  // Authenticated admin users
  if (user.role === "admin") {
    return (
      <Switch>
        <Route path="/" component={AdminDashboard} />
        <Route path="/admin/*" nest component={() => <AdminRoutes />} />
        <Route component={NotFound} />
      </Switch>
    );
  }

  // Authenticated regular users
  return (
    <Switch>
      <Route path="/" component={UserDashboard} />
      <Route path="/dashboard/*" nest component={() => <UserRoutes />} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
