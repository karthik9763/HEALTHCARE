import { Button } from "@/components/ui/button";
import { startLogin } from "@/const";
import { AlertCircle, MapPin, Users, Zap, Shield, BarChart3 } from "lucide-react";

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-red-50">
      {/* Navigation */}
      <nav className="border-b border-gray-200 bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-8 h-8 text-red-600" />
            <span className="text-xl font-bold text-gray-900">AmbulanceTrack</span>
          </div>
          <Button onClick={() => startLogin()} className="bg-red-600 hover:bg-red-700">
            Sign In
          </Button>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div>
            <h1 className="text-5xl font-bold text-gray-900 mb-6">
              Emergency Response, <span className="text-red-600">Faster Than Ever</span>
            </h1>
            <p className="text-xl text-gray-600 mb-8">
              Real-time ambulance dispatch, live tracking, and AI-powered health guidance. Save lives with intelligent emergency management.
            </p>
            <div className="flex gap-4">
              <Button onClick={() => startLogin()} className="bg-red-600 hover:bg-red-700 text-white px-8 py-6 text-lg">
                Get Started
              </Button>
              <Button variant="outline" className="px-8 py-6 text-lg">
                Learn More
              </Button>
            </div>
          </div>
          <div className="bg-gradient-to-br from-red-100 to-blue-100 rounded-2xl p-8 flex items-center justify-center h-96">
            <div className="text-center">
              <AlertCircle className="w-24 h-24 text-red-600 mx-auto mb-4 animate-pulse" />
              <p className="text-gray-600 font-semibold">Emergency Response System</p>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="bg-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-4xl font-bold text-center text-gray-900 mb-16">
            Powerful Features for Emergency Management
          </h2>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                icon: MapPin,
                title: "Real-Time Tracking",
                description: "Live GPS tracking of ambulances with route optimization and traffic analysis"
              },
              {
                icon: Users,
                title: "Admin Control",
                description: "Comprehensive management of users, ambulances, drivers, and hospitals"
              },
              {
                icon: Zap,
                title: "AI Health Guidance",
                description: "Smart recommendations based on health metrics and emergency severity"
              },
              {
                icon: Shield,
                title: "Secure & Reliable",
                description: "JWT authentication with role-based access control and audit trails"
              },
              {
                icon: BarChart3,
                title: "Analytics & Reports",
                description: "Comprehensive reporting with PDF, Excel, and CSV export options"
              },
              {
                icon: AlertCircle,
                title: "Emergency Alerts",
                description: "Instant notifications for emergency requests and ambulance assignments"
              }
            ].map((feature, i) => (
              <div key={i} className="p-6 border border-gray-200 rounded-lg hover:shadow-lg transition">
                <feature.icon className="w-12 h-12 text-red-600 mb-4" />
                <h3 className="text-xl font-semibold text-gray-900 mb-2">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="bg-gradient-to-r from-red-600 to-red-700 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-4xl font-bold mb-2">24/7</div>
              <p className="text-red-100">Round-the-Clock Operations</p>
            </div>
            <div>
              <div className="text-4xl font-bold mb-2">Real-Time</div>
              <p className="text-red-100">Live Ambulance Tracking</p>
            </div>
            <div>
              <div className="text-4xl font-bold mb-2">AI-Powered</div>
              <p className="text-red-100">Health Recommendations</p>
            </div>
            <div>
              <div className="text-4xl font-bold mb-2">Secure</div>
              <p className="text-red-100">Enterprise-Grade Security</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 text-center">
        <h2 className="text-4xl font-bold text-gray-900 mb-6">
          Ready to Transform Emergency Response?
        </h2>
        <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
          Join healthcare providers and emergency services using AmbulanceTrack to save lives through intelligent dispatch and real-time coordination.
        </p>
        <Button onClick={() => startLogin()} className="bg-red-600 hover:bg-red-700 text-white px-10 py-6 text-lg">
          Start Your Free Trial
        </Button>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-gray-400 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <AlertCircle className="w-6 h-6 text-red-600" />
                <span className="font-bold text-white">AmbulanceTrack</span>
              </div>
              <p className="text-sm">Emergency response management system</p>
            </div>
            <div>
              <h4 className="font-semibold text-white mb-4">Product</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="#" className="hover:text-white">Features</a></li>
                <li><a href="#" className="hover:text-white">Pricing</a></li>
                <li><a href="#" className="hover:text-white">Security</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-white mb-4">Company</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="#" className="hover:text-white">About</a></li>
                <li><a href="#" className="hover:text-white">Blog</a></li>
                <li><a href="#" className="hover:text-white">Contact</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-white mb-4">Legal</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="#" className="hover:text-white">Privacy</a></li>
                <li><a href="#" className="hover:text-white">Terms</a></li>
                <li><a href="#" className="hover:text-white">Compliance</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 pt-8 text-center text-sm">
            <p>&copy; 2026 AmbulanceTrack. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
