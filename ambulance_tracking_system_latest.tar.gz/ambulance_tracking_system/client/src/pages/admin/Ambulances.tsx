import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export default function AdminAmbulances() {
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Ambulance Management</h1>
        <Button>Add Ambulance</Button>
      </div>
      <Card>
        <CardHeader>
          <CardTitle>Ambulances</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-500">Ambulance management panel coming soon...</p>
        </CardContent>
      </Card>
    </div>
  );
}
