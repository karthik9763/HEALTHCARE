import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Users, Ambulance, AlertCircle, CheckCircle, Clock, Heart, Activity } from "lucide-react";
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";

export default function AdminDashboard() {
  const { data: stats, isLoading: statsLoading } = trpc.dashboard.getStats.useQuery();
  const { data: activities, isLoading: activitiesLoading } = trpc.dashboard.getRecentActivity.useQuery();

  const StatCard = ({ title, value, icon: Icon, color }: any) => (
    <Card className="border-l-4" style={{ borderLeftColor: color }}>
      <CardHeader className="pb-2">
        <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
          <Icon className="w-4 h-4" style={{ color }} />
          {title}
        </CardTitle>
      </CardHeader>
      <CardContent>
        {statsLoading ? <Skeleton className="h-8 w-16" /> : <div className="text-2xl font-bold">{value}</div>}
      </CardContent>
    </Card>
  );

  // Mock data for charts
  const dailyData = [
    { date: "Mon", emergencies: 12, completed: 10 },
    { date: "Tue", emergencies: 19, completed: 15 },
    { date: "Wed", emergencies: 15, completed: 12 },
    { date: "Thu", emergencies: 22, completed: 18 },
    { date: "Fri", emergencies: 18, completed: 16 },
    { date: "Sat", emergencies: 25, completed: 22 },
    { date: "Sun", emergencies: 14, completed: 12 },
  ];

  const ambulanceStatusData = [
    { status: "Available", count: stats?.availableAmbulances || 0 },
    { status: "Busy", count: stats?.busyAmbulances || 0 },
    { status: "Maintenance", count: 2 },
    { status: "Offline", count: 1 },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Dashboard</h1>
        <p className="text-gray-600">Welcome to the Ambulance Tracking System</p>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Total Users"
          value={stats?.totalUsers || 0}
          icon={Users}
          color="#3b82f6"
        />
        <StatCard
          title="Total Ambulances"
          value={stats?.totalAmbulances || 0}
          icon={Ambulance}
          color="#10b981"
        />
        <StatCard
          title="Active Emergencies"
          value={stats?.activeEmergencies || 0}
          icon={AlertCircle}
          color="#ef4444"
        />
        <StatCard
          title="Completed Cases"
          value={stats?.completedCases || 0}
          icon={CheckCircle}
          color="#8b5cf6"
        />
      </div>

      {/* Additional Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <StatCard
          title="Online Ambulances"
          value={stats?.onlineAmbulances || 0}
          icon={Activity}
          color="#06b6d4"
        />
        <StatCard
          title="Available Ambulances"
          value={stats?.availableAmbulances || 0}
          icon={Ambulance}
          color="#10b981"
        />
        <StatCard
          title="Busy Ambulances"
          value={stats?.busyAmbulances || 0}
          icon={Clock}
          color="#f59e0b"
        />
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Daily Emergency Statistics</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={dailyData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="emergencies" stroke="#ef4444" />
                <Line type="monotone" dataKey="completed" stroke="#10b981" />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Ambulance Status Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={ambulanceStatusData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="status" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="count" fill="#3b82f6" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Recent Activity */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Activity</CardTitle>
        </CardHeader>
        <CardContent>
          {activitiesLoading ? (
            <div className="space-y-2">
              {[...Array(5)].map((_, i) => (
                <Skeleton key={i} className="h-10 w-full" />
              ))}
            </div>
          ) : activities && activities.length > 0 ? (
            <div className="space-y-3">
              {activities.map((activity) => (
                <div key={activity.id} className="flex items-start gap-3 pb-3 border-b last:border-b-0">
                  <div className="w-2 h-2 rounded-full bg-blue-500 mt-2 flex-shrink-0" />
                  <div className="flex-1">
                    <p className="text-sm font-medium capitalize">{activity.action.replace(/_/g, " ")}</p>
                    <p className="text-xs text-gray-500">
                      {new Date(activity.createdAt).toLocaleString()}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-gray-500 text-sm">No recent activities</p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
