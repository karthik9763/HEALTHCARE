import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function AdminEmergencies() {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Emergency Requests</h1>
      <Card>
        <CardHeader>
          <CardTitle>Active Emergencies</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-500">Emergency requests panel coming soon...</p>
        </CardContent>
      </Card>
    </div>
  );
}
