import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export default function AdminHospitals() {
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Hospital Management</h1>
        <Button>Add Hospital</Button>
      </div>
      <Card>
        <CardHeader>
          <CardTitle>Hospitals</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-500">Hospital management panel coming soon...</p>
        </CardContent>
      </Card>
    </div>
  );
}
