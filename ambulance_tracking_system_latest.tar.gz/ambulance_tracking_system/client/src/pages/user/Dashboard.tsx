import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { AlertCircle, MapPin, Clock, Phone } from "lucide-react";

export default function UserDashboard() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Emergency Dashboard</h1>
        <p className="text-gray-600">Your current emergency status and information</p>
      </div>

      <Card className="border-2 border-red-200 bg-red-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-red-700">
            <AlertCircle className="w-5 h-5" />
            No Active Emergency
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Button className="bg-red-600 hover:bg-red-700">Request Ambulance</Button>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card>
          <CardHeader>
            <CardTitle className="text-sm">Nearby Hospitals</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-gray-500 text-sm">No active emergency</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-sm">Emergency Contacts</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-gray-500 text-sm">Manage your emergency contacts</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
