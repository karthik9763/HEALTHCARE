import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export default function UserEmergencyContacts() {
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Emergency Contacts</h1>
        <Button>Add Contact</Button>
      </div>
      <Card>
        <CardHeader>
          <CardTitle>Your Emergency Contacts</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-500">Emergency contacts management coming soon...</p>
        </CardContent>
      </Card>
    </div>
  );
}
