import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function UserTracking() {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Emergency Tracking</h1>
      <Card>
        <CardHeader>
          <CardTitle>Live Tracking</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-500">Live tracking map coming soon...</p>
        </CardContent>
      </Card>
    </div>
  );
}
