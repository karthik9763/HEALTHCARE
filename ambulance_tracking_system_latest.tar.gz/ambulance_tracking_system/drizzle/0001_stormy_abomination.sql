CREATE TABLE `activityLogs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int,
	`action` varchar(100) NOT NULL,
	`entityType` varchar(50),
	`entityId` int,
	`details` json,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `activityLogs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `ambulances` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ambulanceNumber` varchar(50) NOT NULL,
	`registrationNumber` varchar(50) NOT NULL,
	`driverId` int,
	`status` enum('available','busy','maintenance','offline') DEFAULT 'available',
	`currentLatitude` decimal(10,8),
	`currentLongitude` decimal(11,8),
	`fuelLevel` int,
	`gpsStatus` enum('active','inactive','lost_signal') DEFAULT 'active',
	`lastLocationUpdate` timestamp,
	`maintenanceHistory` json,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `ambulances_id` PRIMARY KEY(`id`),
	CONSTRAINT `ambulances_ambulanceNumber_unique` UNIQUE(`ambulanceNumber`)
);
--> statement-breakpoint
CREATE TABLE `drivers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(100) NOT NULL,
	`email` varchar(320),
	`phone` varchar(20) NOT NULL,
	`licenseNumber` varchar(50) NOT NULL,
	`licenseExpiry` datetime,
	`assignedAmbulanceId` int,
	`currentLatitude` decimal(10,8),
	`currentLongitude` decimal(11,8),
	`totalTrips` int DEFAULT 0,
	`rating` decimal(3,2),
	`completedTrips` int DEFAULT 0,
	`drivingHistory` json,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `drivers_id` PRIMARY KEY(`id`),
	CONSTRAINT `drivers_licenseNumber_unique` UNIQUE(`licenseNumber`)
);
--> statement-breakpoint
CREATE TABLE `emergencyContacts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`name` varchar(100) NOT NULL,
	`phone` varchar(20) NOT NULL,
	`email` varchar(320),
	`relationship` varchar(50),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `emergencyContacts_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `emergencyRequests` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`ambulanceId` int,
	`driverId` int,
	`hospitalId` int,
	`status` enum('request_sent','ambulance_assigned','driver_en_route','ambulance_arrived','patient_picked_up','reached_hospital','completed') DEFAULT 'request_sent',
	`priority` enum('low','mild','moderate','high','critical') DEFAULT 'moderate',
	`userLatitude` decimal(10,8) NOT NULL,
	`userLongitude` decimal(11,8) NOT NULL,
	`hospitalLatitude` decimal(10,8),
	`hospitalLongitude` decimal(11,8),
	`estimatedArrivalTime` datetime,
	`distanceRemaining` decimal(10,2),
	`patientDescription` text,
	`completedAt` datetime,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `emergencyRequests_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `healthMetrics` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`emergencyRequestId` int,
	`heartRate` int,
	`systolicBP` int,
	`diastolicBP` int,
	`spO2` int,
	`temperature` decimal(5,2),
	`bloodSugar` int,
	`fallDetected` boolean DEFAULT false,
	`noMovementDetected` boolean DEFAULT false,
	`abnormalMovementDetected` boolean DEFAULT false,
	`severity` enum('low','mild','moderate','high','critical') DEFAULT 'low',
	`recommendations` json,
	`recordedAt` timestamp NOT NULL DEFAULT (now()),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `healthMetrics_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `hospitals` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(100) NOT NULL,
	`address` text,
	`phone` varchar(20),
	`email` varchar(320),
	`latitude` decimal(10,8) NOT NULL,
	`longitude` decimal(11,8) NOT NULL,
	`totalBeds` int,
	`availableBeds` int,
	`icuBeds` int,
	`availableIcuBeds` int,
	`emergencyContacts` json,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `hospitals_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `notifications` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`type` enum('emergency_alert','maintenance_reminder','ambulance_assignment','health_advisory','safety_notification') NOT NULL,
	`title` varchar(200) NOT NULL,
	`message` text,
	`isRead` boolean DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `notifications_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `reports` (
	`id` int AUTO_INCREMENT NOT NULL,
	`reportType` enum('daily','weekly','monthly','emergency','utilization','performance','activity') NOT NULL,
	`generatedBy` int NOT NULL,
	`reportData` json NOT NULL,
	`fileUrl` text,
	`exportFormat` enum('pdf','excel','csv'),
	`generatedAt` timestamp NOT NULL DEFAULT (now()),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `reports_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `users` ADD `phone` varchar(20);--> statement-breakpoint
ALTER TABLE `users` ADD `profilePicture` text;--> statement-breakpoint
ALTER TABLE `users` ADD `isBlocked` boolean DEFAULT false;