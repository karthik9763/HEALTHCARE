import {
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
  decimal,
  boolean,
  json,
  datetime,
} from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow with role-based access control.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  phone: varchar("phone", { length: 20 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  profilePicture: text("profilePicture"), // S3 URL
  isBlocked: boolean("isBlocked").default(false),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Ambulances table for tracking ambulance fleet.
 */
export const ambulances = mysqlTable("ambulances", {
  id: int("id").autoincrement().primaryKey(),
  ambulanceNumber: varchar("ambulanceNumber", { length: 50 }).notNull().unique(),
  registrationNumber: varchar("registrationNumber", { length: 50 }).notNull(),
  driverId: int("driverId"),
  status: mysqlEnum("status", ["available", "busy", "maintenance", "offline"]).default("available"),
  currentLatitude: decimal("currentLatitude", { precision: 10, scale: 8 }),
  currentLongitude: decimal("currentLongitude", { precision: 11, scale: 8 }),
  fuelLevel: int("fuelLevel"), // percentage
  gpsStatus: mysqlEnum("gpsStatus", ["active", "inactive", "lost_signal"]).default("active"),
  lastLocationUpdate: timestamp("lastLocationUpdate"),
  maintenanceHistory: json("maintenanceHistory"), // Array of maintenance records
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Ambulance = typeof ambulances.$inferSelect;
export type InsertAmbulance = typeof ambulances.$inferInsert;

/**
 * Drivers table for managing ambulance drivers.
 */
export const drivers = mysqlTable("drivers", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  email: varchar("email", { length: 320 }),
  phone: varchar("phone", { length: 20 }).notNull(),
  licenseNumber: varchar("licenseNumber", { length: 50 }).notNull().unique(),
  licenseExpiry: datetime("licenseExpiry"),
  assignedAmbulanceId: int("assignedAmbulanceId"),
  currentLatitude: decimal("currentLatitude", { precision: 10, scale: 8 }),
  currentLongitude: decimal("currentLongitude", { precision: 11, scale: 8 }),
  totalTrips: int("totalTrips").default(0),
  rating: decimal("rating", { precision: 3, scale: 2 }), // 0-5 stars
  completedTrips: int("completedTrips").default(0),
  drivingHistory: json("drivingHistory"), // Array of trip records
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Driver = typeof drivers.$inferSelect;
export type InsertDriver = typeof drivers.$inferInsert;

/**
 * Hospitals table for managing hospital network.
 */
export const hospitals = mysqlTable("hospitals", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  address: text("address"),
  phone: varchar("phone", { length: 20 }),
  email: varchar("email", { length: 320 }),
  latitude: decimal("latitude", { precision: 10, scale: 8 }).notNull(),
  longitude: decimal("longitude", { precision: 11, scale: 8 }).notNull(),
  totalBeds: int("totalBeds"),
  availableBeds: int("availableBeds"),
  icuBeds: int("icuBeds"),
  availableIcuBeds: int("availableIcuBeds"),
  emergencyContacts: json("emergencyContacts"), // Array of contact objects
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Hospital = typeof hospitals.$inferSelect;
export type InsertHospital = typeof hospitals.$inferInsert;

/**
 * Emergency requests table for managing emergency cases.
 */
export const emergencyRequests = mysqlTable("emergencyRequests", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  ambulanceId: int("ambulanceId"),
  driverId: int("driverId"),
  hospitalId: int("hospitalId"),
  status: mysqlEnum("status", [
    "request_sent",
    "ambulance_assigned",
    "driver_en_route",
    "ambulance_arrived",
    "patient_picked_up",
    "reached_hospital",
    "completed",
  ]).default("request_sent"),
  priority: mysqlEnum("priority", ["low", "mild", "moderate", "high", "critical"]).default("moderate"),
  userLatitude: decimal("userLatitude", { precision: 10, scale: 8 }).notNull(),
  userLongitude: decimal("userLongitude", { precision: 11, scale: 8 }).notNull(),
  hospitalLatitude: decimal("hospitalLatitude", { precision: 10, scale: 8 }),
  hospitalLongitude: decimal("hospitalLongitude", { precision: 11, scale: 8 }),
  estimatedArrivalTime: datetime("estimatedArrivalTime"),
  distanceRemaining: decimal("distanceRemaining", { precision: 10, scale: 2 }), // in km
  patientDescription: text("patientDescription"),
  completedAt: datetime("completedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type EmergencyRequest = typeof emergencyRequests.$inferSelect;
export type InsertEmergencyRequest = typeof emergencyRequests.$inferInsert;

/**
 * Health metrics table for tracking patient health data.
 */
export const healthMetrics = mysqlTable("healthMetrics", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  emergencyRequestId: int("emergencyRequestId"),
  heartRate: int("heartRate"), // bpm
  systolicBP: int("systolicBP"), // mmHg
  diastolicBP: int("diastolicBP"), // mmHg
  spO2: int("spO2"), // percentage
  temperature: decimal("temperature", { precision: 5, scale: 2 }), // Celsius
  bloodSugar: int("bloodSugar"), // mg/dL
  fallDetected: boolean("fallDetected").default(false),
  noMovementDetected: boolean("noMovementDetected").default(false),
  abnormalMovementDetected: boolean("abnormalMovementDetected").default(false),
  severity: mysqlEnum("severity", ["low", "mild", "moderate", "high", "critical"]).default("low"),
  recommendations: json("recommendations"), // Array of AI recommendations
  recordedAt: timestamp("recordedAt").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type HealthMetric = typeof healthMetrics.$inferSelect;
export type InsertHealthMetric = typeof healthMetrics.$inferInsert;

/**
 * Emergency contacts table for users to manage their emergency contacts.
 */
export const emergencyContacts = mysqlTable("emergencyContacts", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  name: varchar("name", { length: 100 }).notNull(),
  phone: varchar("phone", { length: 20 }).notNull(),
  email: varchar("email", { length: 320 }),
  relationship: varchar("relationship", { length: 50 }), // family, doctor, etc.
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type EmergencyContact = typeof emergencyContacts.$inferSelect;
export type InsertEmergencyContact = typeof emergencyContacts.$inferInsert;

/**
 * Activity logs table for audit trails and recent activity feed.
 */
export const activityLogs = mysqlTable("activityLogs", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId"),
  action: varchar("action", { length: 100 }).notNull(), // e.g., "emergency_request_created", "ambulance_assigned"
  entityType: varchar("entityType", { length: 50 }), // e.g., "emergency_request", "ambulance"
  entityId: int("entityId"),
  details: json("details"), // Additional context
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ActivityLog = typeof activityLogs.$inferSelect;
export type InsertActivityLog = typeof activityLogs.$inferInsert;

/**
 * Reports table for storing generated reports.
 */
export const reports = mysqlTable("reports", {
  id: int("id").autoincrement().primaryKey(),
  reportType: mysqlEnum("reportType", [
    "daily",
    "weekly",
    "monthly",
    "emergency",
    "utilization",
    "performance",
    "activity",
  ]).notNull(),
  generatedBy: int("generatedBy").notNull(), // admin user id
  reportData: json("reportData").notNull(), // Report content
  fileUrl: text("fileUrl"), // S3 URL for exported file
  exportFormat: mysqlEnum("exportFormat", ["pdf", "excel", "csv"]),
  generatedAt: timestamp("generatedAt").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Report = typeof reports.$inferSelect;
export type InsertReport = typeof reports.$inferInsert;

/**
 * Notifications table for storing push notifications.
 */
export const notifications = mysqlTable("notifications", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  type: mysqlEnum("type", [
    "emergency_alert",
    "maintenance_reminder",
    "ambulance_assignment",
    "health_advisory",
    "safety_notification",
  ]).notNull(),
  title: varchar("title", { length: 200 }).notNull(),
  message: text("message"),
  isRead: boolean("isRead").default(false),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = typeof notifications.$inferInsert;
