import { eq, and, like, desc, asc, gte, lte, inArray } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  InsertUser,
  users,
  ambulances,
  drivers,
  hospitals,
  emergencyRequests,
  healthMetrics,
  emergencyContacts,
  activityLogs,
  notifications,
  reports,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "phone", "loginMethod", "profilePicture"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = "admin";
      updateSet.role = "admin";
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getUserById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// User Management
export async function getAllUsers(limit = 100, offset = 0) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(users).limit(limit).offset(offset);
}

export async function searchUsers(query: string, limit = 50) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(users)
    .where(
      or(
        like(users.name, `%${query}%`),
        like(users.email, `%${query}%`),
        like(users.phone, `%${query}%`)
      )
    )
    .limit(limit);
}

export async function updateUserRole(userId: number, role: "admin" | "user") {
  const db = await getDb();
  if (!db) return null;
  return db.update(users).set({ role }).where(eq(users.id, userId));
}

export async function blockUser(userId: number) {
  const db = await getDb();
  if (!db) return null;
  return db.update(users).set({ isBlocked: true }).where(eq(users.id, userId));
}

export async function unblockUser(userId: number) {
  const db = await getDb();
  if (!db) return null;
  return db.update(users).set({ isBlocked: false }).where(eq(users.id, userId));
}

// Ambulance Management
export async function getAllAmbulances() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(ambulances);
}

export async function getAmbulanceById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(ambulances).where(eq(ambulances.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createAmbulance(data: typeof ambulances.$inferInsert) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.insert(ambulances).values(data);
  return result;
}

export async function updateAmbulanceStatus(ambulanceId: number, status: string) {
  const db = await getDb();
  if (!db) return null;
  return db.update(ambulances).set({ status: status as any }).where(eq(ambulances.id, ambulanceId));
}

export async function updateAmbulanceLocation(
  ambulanceId: number,
  latitude: string,
  longitude: string
) {
  const db = await getDb();
  if (!db) return null;
  return db
    .update(ambulances)
    .set({
      currentLatitude: latitude as any,
      currentLongitude: longitude as any,
      lastLocationUpdate: new Date(),
    })
    .where(eq(ambulances.id, ambulanceId));
}

export async function getAvailableAmbulances() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(ambulances).where(eq(ambulances.status, "available"));
}

// Driver Management
export async function getAllDrivers() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(drivers);
}

export async function getDriverById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(drivers).where(eq(drivers.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createDriver(data: typeof drivers.$inferInsert) {
  const db = await getDb();
  if (!db) return null;
  return db.insert(drivers).values(data);
}

export async function assignAmbulanceToDriver(driverId: number, ambulanceId: number) {
  const db = await getDb();
  if (!db) return null;
  return db.update(drivers).set({ assignedAmbulanceId: ambulanceId }).where(eq(drivers.id, driverId));
}

// Hospital Management
export async function getAllHospitals() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(hospitals);
}

export async function getHospitalById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(hospitals).where(eq(hospitals.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createHospital(data: typeof hospitals.$inferInsert) {
  const db = await getDb();
  if (!db) return null;
  return db.insert(hospitals).values(data);
}

export async function updateHospitalBedAvailability(
  hospitalId: number,
  availableBeds: number,
  availableIcuBeds: number
) {
  const db = await getDb();
  if (!db) return null;
  return db
    .update(hospitals)
    .set({ availableBeds, availableIcuBeds })
    .where(eq(hospitals.id, hospitalId));
}

// Emergency Requests
export async function getAllEmergencyRequests() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(emergencyRequests).orderBy(desc(emergencyRequests.createdAt));
}

export async function getEmergencyRequestById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db
    .select()
    .from(emergencyRequests)
    .where(eq(emergencyRequests.id, id))
    .limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getUserEmergencyRequests(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(emergencyRequests)
    .where(eq(emergencyRequests.userId, userId))
    .orderBy(desc(emergencyRequests.createdAt));
}

export async function createEmergencyRequest(data: typeof emergencyRequests.$inferInsert) {
  const db = await getDb();
  if (!db) return null;
  return db.insert(emergencyRequests).values(data);
}

export async function updateEmergencyRequestStatus(emergencyRequestId: number, status: string) {
  const db = await getDb();
  if (!db) return null;
  return db
    .update(emergencyRequests)
    .set({ status: status as any })
    .where(eq(emergencyRequests.id, emergencyRequestId));
}

export async function assignAmbulanceToEmergency(
  emergencyRequestId: number,
  ambulanceId: number,
  driverId: number,
  hospitalId: number
) {
  const db = await getDb();
  if (!db) return null;
  return db
    .update(emergencyRequests)
    .set({ ambulanceId, driverId, hospitalId, status: "ambulance_assigned" as any })
    .where(eq(emergencyRequests.id, emergencyRequestId));
}

export async function getActiveEmergencies() {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(emergencyRequests)
    .where(
      inArray(emergencyRequests.status, [
        "request_sent",
        "ambulance_assigned",
        "driver_en_route",
        "ambulance_arrived",
        "patient_picked_up",
      ])
    );
}

// Health Metrics
export async function createHealthMetric(data: typeof healthMetrics.$inferInsert) {
  const db = await getDb();
  if (!db) return null;
  return db.insert(healthMetrics).values(data);
}

export async function getUserHealthMetrics(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(healthMetrics)
    .where(eq(healthMetrics.userId, userId))
    .orderBy(desc(healthMetrics.recordedAt));
}

export async function getLatestHealthMetric(userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db
    .select()
    .from(healthMetrics)
    .where(eq(healthMetrics.userId, userId))
    .orderBy(desc(healthMetrics.recordedAt))
    .limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// Emergency Contacts
export async function getUserEmergencyContacts(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(emergencyContacts).where(eq(emergencyContacts.userId, userId));
}

export async function createEmergencyContact(data: typeof emergencyContacts.$inferInsert) {
  const db = await getDb();
  if (!db) return null;
  return db.insert(emergencyContacts).values(data);
}

export async function deleteEmergencyContact(contactId: number) {
  const db = await getDb();
  if (!db) return null;
  return db.delete(emergencyContacts).where(eq(emergencyContacts.id, contactId));
}

// Activity Logs
export async function logActivity(data: typeof activityLogs.$inferInsert) {
  const db = await getDb();
  if (!db) return null;
  return db.insert(activityLogs).values(data);
}

export async function getRecentActivity(limit = 50) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(activityLogs).orderBy(desc(activityLogs.createdAt)).limit(limit);
}

// Notifications
export async function createNotification(data: typeof notifications.$inferInsert) {
  const db = await getDb();
  if (!db) return null;
  return db.insert(notifications).values(data);
}

export async function getUserNotifications(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(notifications)
    .where(eq(notifications.userId, userId))
    .orderBy(desc(notifications.createdAt));
}

export async function markNotificationAsRead(notificationId: number) {
  const db = await getDb();
  if (!db) return null;
  return db.update(notifications).set({ isRead: true }).where(eq(notifications.id, notificationId));
}

// Reports
export async function createReport(data: typeof reports.$inferInsert) {
  const db = await getDb();
  if (!db) return null;
  return db.insert(reports).values(data);
}

export async function getReports(reportType?: string) {
  const db = await getDb();
  if (!db) return [];
  if (reportType) {
    return db.select().from(reports).where(eq(reports.reportType, reportType as any));
  }
  return db.select().from(reports).orderBy(desc(reports.createdAt));
}

// Dashboard Statistics
export async function getDashboardStats() {
  const db = await getDb();
  if (!db) return null;

  const totalUsers = await db.select().from(users);
  const totalAmbulances = await db.select().from(ambulances);
  const activeEmergencies = await db
    .select()
    .from(emergencyRequests)
    .where(
      inArray(emergencyRequests.status, [
        "request_sent",
        "ambulance_assigned",
        "driver_en_route",
        "ambulance_arrived",
        "patient_picked_up",
      ])
    );
  const completedCases = await db
    .select()
    .from(emergencyRequests)
    .where(eq(emergencyRequests.status, "completed"));
  const onlineAmbulances = await db
    .select()
    .from(ambulances)
    .where(eq(ambulances.gpsStatus, "active"));
  const availableAmbulances = await db
    .select()
    .from(ambulances)
    .where(eq(ambulances.status, "available"));
  const busyAmbulances = await db
    .select()
    .from(ambulances)
    .where(eq(ambulances.status, "busy"));

  return {
    totalUsers: totalUsers.length,
    totalAmbulances: totalAmbulances.length,
    activeEmergencies: activeEmergencies.length,
    completedCases: completedCases.length,
    onlineAmbulances: onlineAmbulances.length,
    availableAmbulances: availableAmbulances.length,
    busyAmbulances: busyAmbulances.length,
  };
}

// Helper for OR conditions
function or(...conditions: any[]) {
  return conditions.reduce((acc, cond) => (acc ? { ...acc, or: cond } : cond));
}
