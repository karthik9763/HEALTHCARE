import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";
import { TRPCError } from "@trpc/server";

// Helper to ensure admin access
const adminProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== "admin") {
    throw new TRPCError({ code: "FORBIDDEN", message: "Admin access required" });
  }
  return next({ ctx });
});

export const appRouter = router({
  system: systemRouter,

  // Authentication
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  // Dashboard
  dashboard: router({
    getStats: adminProcedure.query(async () => {
      return await db.getDashboardStats();
    }),
    getRecentActivity: adminProcedure.query(async () => {
      return await db.getRecentActivity(20);
    }),
  }),

  // User Management
  users: router({
    list: adminProcedure.query(async ({ input }) => {
      return await db.getAllUsers();
    }),
    search: adminProcedure.input(z.object({ query: z.string() })).query(async ({ input }) => {
      return await db.searchUsers(input.query);
    }),
    getById: adminProcedure.input(z.object({ id: z.number() })).query(async ({ input }) => {
      return await db.getUserById(input.id);
    }),
    updateRole: adminProcedure
      .input(z.object({ userId: z.number(), role: z.enum(["admin", "user"]) }))
      .mutation(async ({ input }) => {
        await db.updateUserRole(input.userId, input.role);
        return { success: true };
      }),
    block: adminProcedure
      .input(z.object({ userId: z.number() }))
      .mutation(async ({ input }) => {
        await db.blockUser(input.userId);
        await db.logActivity({
          userId: input.userId,
          action: "user_blocked",
          entityType: "user",
          entityId: input.userId,
        });
        return { success: true };
      }),
    unblock: adminProcedure
      .input(z.object({ userId: z.number() }))
      .mutation(async ({ input }) => {
        await db.unblockUser(input.userId);
        await db.logActivity({
          userId: input.userId,
          action: "user_unblocked",
          entityType: "user",
          entityId: input.userId,
        });
        return { success: true };
      }),
  }),

  // Ambulance Management
  ambulances: router({
    list: adminProcedure.query(async () => {
      return await db.getAllAmbulances();
    }),
    getById: adminProcedure.input(z.object({ id: z.number() })).query(async ({ input }) => {
      return await db.getAmbulanceById(input.id);
    }),
    create: adminProcedure
      .input(
        z.object({
          ambulanceNumber: z.string(),
          registrationNumber: z.string(),
          driverId: z.number().optional(),
        })
      )
      .mutation(async ({ input }) => {
        await db.createAmbulance({
          ambulanceNumber: input.ambulanceNumber,
          registrationNumber: input.registrationNumber,
          driverId: input.driverId,
        });
        return { success: true };
      }),
    updateStatus: adminProcedure
      .input(z.object({ ambulanceId: z.number(), status: z.string() }))
      .mutation(async ({ input }) => {
        await db.updateAmbulanceStatus(input.ambulanceId, input.status);
        return { success: true };
      }),
    updateLocation: adminProcedure
      .input(z.object({ ambulanceId: z.number(), latitude: z.string(), longitude: z.string() }))
      .mutation(async ({ input }) => {
        await db.updateAmbulanceLocation(input.ambulanceId, input.latitude, input.longitude);
        return { success: true };
      }),
    getAvailable: publicProcedure.query(async () => {
      return await db.getAvailableAmbulances();
    }),
  }),

  // Driver Management
  drivers: router({
    list: adminProcedure.query(async () => {
      return await db.getAllDrivers();
    }),
    getById: adminProcedure.input(z.object({ id: z.number() })).query(async ({ input }) => {
      return await db.getDriverById(input.id);
    }),
    create: adminProcedure
      .input(
        z.object({
          name: z.string(),
          email: z.string().optional(),
          phone: z.string(),
          licenseNumber: z.string(),
        })
      )
      .mutation(async ({ input }) => {
        await db.createDriver({
          name: input.name,
          email: input.email,
          phone: input.phone,
          licenseNumber: input.licenseNumber,
        });
        return { success: true };
      }),
    assignAmbulance: adminProcedure
      .input(z.object({ driverId: z.number(), ambulanceId: z.number() }))
      .mutation(async ({ input }) => {
        await db.assignAmbulanceToDriver(input.driverId, input.ambulanceId);
        return { success: true };
      }),
  }),

  // Hospital Management
  hospitals: router({
    list: protectedProcedure.query(async () => {
      return await db.getAllHospitals();
    }),
    getById: protectedProcedure.input(z.object({ id: z.number() })).query(async ({ input }) => {
      return await db.getHospitalById(input.id);
    }),
    create: adminProcedure
      .input(
        z.object({
          name: z.string(),
          address: z.string().optional(),
          phone: z.string().optional(),
          email: z.string().optional(),
          latitude: z.string(),
          longitude: z.string(),
          totalBeds: z.number().optional(),
          icuBeds: z.number().optional(),
        })
      )
      .mutation(async ({ input }) => {
        await db.createHospital({
          name: input.name,
          address: input.address,
          phone: input.phone,
          email: input.email,
          latitude: input.latitude as any,
          longitude: input.longitude as any,
          totalBeds: input.totalBeds,
          icuBeds: input.icuBeds,
          availableBeds: input.totalBeds,
          availableIcuBeds: input.icuBeds,
        });
        return { success: true };
      }),
    updateBedAvailability: adminProcedure
      .input(
        z.object({
          hospitalId: z.number(),
          availableBeds: z.number(),
          availableIcuBeds: z.number(),
        })
      )
      .mutation(async ({ input }) => {
        await db.updateHospitalBedAvailability(
          input.hospitalId,
          input.availableBeds,
          input.availableIcuBeds
        );
        return { success: true };
      }),
  }),

  // Emergency Requests
  emergencies: router({
    list: adminProcedure.query(async () => {
      return await db.getAllEmergencyRequests();
    }),
    getById: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input, ctx }) => {
        const emergency = await db.getEmergencyRequestById(input.id);
        if (!emergency) throw new TRPCError({ code: "NOT_FOUND" });
        // Users can only view their own emergencies
        if (ctx.user.role !== "admin" && emergency.userId !== ctx.user.id) {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        return emergency;
      }),
    getUserEmergencies: protectedProcedure.query(async ({ ctx }) => {
      return await db.getUserEmergencyRequests(ctx.user.id);
    }),
    create: protectedProcedure
      .input(
        z.object({
          latitude: z.string(),
          longitude: z.string(),
          patientDescription: z.string().optional(),
          priority: z.enum(["low", "mild", "moderate", "high", "critical"]).optional(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        await db.createEmergencyRequest({
          userId: ctx.user.id,
          userLatitude: input.latitude as any,
          userLongitude: input.longitude as any,
          patientDescription: input.patientDescription,
          priority: (input.priority || "moderate") as any,
          status: "request_sent" as any,
        });
        await db.logActivity({
          userId: ctx.user.id,
          action: "emergency_request_created",
          entityType: "emergency_request",
        });
        return { success: true };
      }),
    updateStatus: adminProcedure
      .input(z.object({ emergencyId: z.number(), status: z.string() }))
      .mutation(async ({ input }) => {
        await db.updateEmergencyRequestStatus(input.emergencyId, input.status);
        return { success: true };
      }),
    assignAmbulance: adminProcedure
      .input(
        z.object({
          emergencyId: z.number(),
          ambulanceId: z.number(),
          driverId: z.number(),
          hospitalId: z.number(),
        })
      )
      .mutation(async ({ input }) => {
        await db.assignAmbulanceToEmergency(
          input.emergencyId,
          input.ambulanceId,
          input.driverId,
          input.hospitalId
        );
        await db.logActivity({
          action: "ambulance_assigned",
          entityType: "emergency_request",
          entityId: input.emergencyId,
        });
        return { success: true };
      }),
    getActive: adminProcedure.query(async () => {
      return await db.getActiveEmergencies();
    }),
  }),

  // Health Metrics
  healthMetrics: router({
    create: protectedProcedure
      .input(
        z.object({
          heartRate: z.number().optional(),
          systolicBP: z.number().optional(),
          diastolicBP: z.number().optional(),
          spO2: z.number().optional(),
          temperature: z.number().optional(),
          bloodSugar: z.number().optional(),
          fallDetected: z.boolean().optional(),
          noMovementDetected: z.boolean().optional(),
          abnormalMovementDetected: z.boolean().optional(),
          severity: z.enum(["low", "mild", "moderate", "high", "critical"]).optional(),
          recommendations: z.array(z.string()).optional(),
          emergencyRequestId: z.number().optional(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        await db.createHealthMetric({
          userId: ctx.user.id,
          heartRate: input.heartRate,
          systolicBP: input.systolicBP,
          diastolicBP: input.diastolicBP,
          spO2: input.spO2,
          temperature: input.temperature as any,
          bloodSugar: input.bloodSugar,
          fallDetected: input.fallDetected,
          noMovementDetected: input.noMovementDetected,
          abnormalMovementDetected: input.abnormalMovementDetected,
          severity: (input.severity || "low") as any,
          recommendations: input.recommendations as any,
          emergencyRequestId: input.emergencyRequestId,
        });
        return { success: true };
      }),
    getUserMetrics: protectedProcedure.query(async ({ ctx }) => {
      return await db.getUserHealthMetrics(ctx.user.id);
    }),
    getLatest: protectedProcedure.query(async ({ ctx }) => {
      return await db.getLatestHealthMetric(ctx.user.id);
    }),
  }),

  // Emergency Contacts
  emergencyContacts: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return await db.getUserEmergencyContacts(ctx.user.id);
    }),
    create: protectedProcedure
      .input(
        z.object({
          name: z.string(),
          phone: z.string(),
          email: z.string().optional(),
          relationship: z.string().optional(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        await db.createEmergencyContact({
          userId: ctx.user.id,
          name: input.name,
          phone: input.phone,
          email: input.email,
          relationship: input.relationship,
        });
        return { success: true };
      }),
    delete: protectedProcedure
      .input(z.object({ contactId: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteEmergencyContact(input.contactId);
        return { success: true };
      }),
  }),

  // Notifications
  notifications: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return await db.getUserNotifications(ctx.user.id);
    }),
    markAsRead: protectedProcedure
      .input(z.object({ notificationId: z.number() }))
      .mutation(async ({ input }) => {
        await db.markNotificationAsRead(input.notificationId);
        return { success: true };
      }),
  }),

  // Reports
  reports: router({
    list: adminProcedure
      .input(z.object({ reportType: z.string().optional() }))
      .query(async ({ input }) => {
        return await db.getReports(input.reportType);
      }),
    create: adminProcedure
      .input(
        z.object({
          reportType: z.enum([
            "daily",
            "weekly",
            "monthly",
            "emergency",
            "utilization",
            "performance",
            "activity",
          ]),
          reportData: z.record(z.string(), z.any()),
          exportFormat: z.enum(["pdf", "excel", "csv"]).optional(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        await db.createReport({
          reportType: input.reportType as any,
          generatedBy: ctx.user.id,
          reportData: input.reportData as any,
          exportFormat: (input.exportFormat || "pdf") as any,
        });
        return { success: true };
      }),
  }),
});

export type AppRouter = typeof appRouter;
